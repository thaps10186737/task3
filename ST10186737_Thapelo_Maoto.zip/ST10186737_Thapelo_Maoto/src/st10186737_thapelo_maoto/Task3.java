/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package st10186737_thapelo_maoto;

import javax.swing.*;
import task.pkg2.NewClass;

/**
 *
 * @author Thapelo Maoto
 */

 
 
 
class Task3 {


    public static void main(String[] args) {
    
       
        StringBuilder brick = new StringBuilder();
        StringBuilder mansonry = new StringBuilder();
        //Array field
        String[] dev = {"Tim Gordon", "Tom Miller", "Victor Vilakazi", "Mary Ndlovu"};

        String[] taskName = {"Business task", "Military task", "SpaceProgram task", "Government task"};

        int[] durat = new int[]{4, 34, 10, 12};

        String[] taskStatus = {"Do", "Doing", "Done", "Done"};
        for (int i = 0; i < dev.length; i++) {
            brick.append(taskName[i] + "\n" + dev[i] + "\n" + durat[i] + "\n" + taskStatus[i]+"\n"+"\n");
        }

        JOptionPane.showMessageDialog(null, brick.toString());

        for (int i = 0; i < taskName.length; i++) {
            
        }

        for (int i = 0; i < dev.length; i++) {

            JOptionPane.showMessageDialog(null, taskName[i] + ":" + dev[i]);
        }

        // Evaluation of task with longer duration
        int large = durat[0];
        int small = durat[0];
        for (int i = 0; i < durat.length; i++) {
            if (large < durat[i]) {
                large = durat[i];
                JOptionPane.showMessageDialog(null, "Task with greatest duration: " + large + "Hours" + dev[i]);
                
        String searchStatus = JOptionPane.showInputDialog(null,"Enter task status");
        
                        
     ///** Search functions
     // search using task name
       String search = JOptionPane.showInputDialog(null,"Enter task"
               + " name to search");
         for(int n = 0; n < taskName.length;n++){
       if(search.equalsIgnoreCase(taskName[n])){  
       
        
        JOptionPane.showMessageDialog(null,"Task Details of:"
                + "\n"
                + " "
                + dev[n]+"\n"+taskName[n]+"\n"+durat[n]+"hours"+"\n"+searchStatus);
         
         //Search using task name
        String scan = JOptionPane.showInputDialog(null,"Enter task name to search");
        for(
            int t = 0; t < taskName.length; t++){
        if(scan.equalsIgnoreCase(taskName[t]))
        { JOptionPane.showMessageDialog(null,"Task Details:"+"\n" +taskName[t] + "\n"+ searchStatus);
        break;}
        }
       
         }
            }

        }   
    } 
       
 //Object for deleting tasks 
NewClass2 a = new NewClass2();
a.display(taskName);

    }

}

       



   

