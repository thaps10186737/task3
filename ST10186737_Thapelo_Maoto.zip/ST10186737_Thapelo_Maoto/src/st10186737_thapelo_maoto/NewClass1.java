/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task.pkg2;

/**
 *
 * @author Thapelo Maoto
 */
public class NewClass1 {
String taskName ="User program";
int number = 0;
String dev_name ="Thapelo";    
    
    
public  void taskId1n(String taskName, int number, String dev_name){
StringBuilder brick = new StringBuilder();        
this.taskName = taskName.substring(0, 2);
this.number = number;
this.dev_name = dev_name.substring(dev_name.length()-3);


}

    
public String toString(){
return taskName +":"+number+":"+ dev_name;

    
}
}