/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;


class password {

    public static void getPassword() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter password>>>");
        String user = sc.nextLine();

        checkPassword(hasLength(user), hasCharacters(user));
    }

    public static boolean checkPassword(boolean l, boolean c) {
        boolean outcome = false;
        if (l && c) {
            outcome = true;
            System.out.println("User registered");
        } else {
            outcome = false;
            System.out.println("Username does not match complexity");
        }
        return outcome;
    }

    public static boolean hasLength(String user) {

        boolean result = false;

        for (int i = 0; i < user.length(); i++) {
            if (user.length() == 5 && user.length() >= 5) {
                result = true;

                break;
            } else {
                result = false;
            }
            break;
        }
        return result;
    }

    public static boolean hasCharacters(String user) {
        boolean output = false;

        for (int j = 0; j < user.length(); j++) {
            if (user.charAt(j) == 95 || user.charAt(j) == 95) {
                output = true;

                break;
            } else {
                output = false;

                break;
            }
        }
        return output;
    }

}

class results extends password {
}

public class Username {

    public static void main(String[] args) {
        results a = new results();
        
        a.getPassword();
        Scanner scan = new Scanner(System.in);
        System.out.println("Give username>>>");
        String username = scan.nextLine();

        
        checkUsernameComplexity(getLength(username), getUpperCase(username), getNumbers(username), getSpecialChar(username));

    }

    public static boolean checkUsernameComplexity(boolean l, boolean uc, boolean n, boolean sc) {
        boolean result = false;
        if (l && uc && n && sc) {
            result = true;
            System.out.println("User registered");
        } else {
            result = false;
            System.out.println("Password does not match complexity");
        }
        return result;
    }

    public static boolean getUpperCase(String username) {
        boolean isCaps = false;
        for (int t = 0; t < username.length(); t++) {
            if (username.charAt(t) >= 65 && username.charAt(t) <= 90) {
                isCaps = true;
                break;
            } else {
                isCaps = false;
            }
        }
        return isCaps;
    }

    public static boolean getSpecialChar(String username) {
        boolean hasSpecial = false;
        for (int i = 0; i < username.length(); i++) {
            if (username.charAt(i) >= 33 && username.charAt(i) <= 47 || username.charAt(i) >= 58 && username.charAt(i) <= 64 || username.charAt(i) >= 91 || username.charAt(i) >= 96 && username.charAt(i)>= 123 || username.charAt(i) <=126) {
                hasSpecial = true;
                break;
            } else {
                hasSpecial = false;
            }
        }
        return hasSpecial;
    }

    public static boolean getNumbers(String username) {
        boolean hasNumber = false;
        for (int n = 0; n < username.length(); n++) {

            if (username.charAt(n) >= 48 && username.charAt(n) <= 57) {
                hasNumber = true;
                break;
            } else {
                hasNumber = false;
                break;
            }
        }
        return hasNumber;
    }

    public static boolean getLength(String username) {
        
        boolean hasLength = false;
        for (int u = 0; u < username.length(); u++) {
            if (username.length() >= 8 || username.length() == 8) {
                hasLength = true;
                break;
            } else {
                hasLength = false;
            }
            break;
        }
        return hasLength;

    }

    public static boolean loginUser(boolean cuc, boolean cp) {
        boolean rs = false;
        if (cuc && cp) {
            rs = true;
            System.out.println("Welcome back user");
        } else {
            rs = false;
            System.out.println("Check login detail and attempt to login once more");
        }

        return rs;
    }

}
