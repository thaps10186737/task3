/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task.pkg2;
import javax.swing.JOptionPane;
/**
 *
 * @author Thapelo Maoto
 */
public class Task {

 //Method to check task description     
 public static boolean checkTaskDescription(String description){
  int len = description.length();
  boolean correctLen = false;
  
  if(len<= 50){correctLen = true;
  JOptionPane.showMessageDialog(null,"Task successfully captured");}
  else{correctLen = false;
  JOptionPane.showMessageDialog(null,"Please enter a task of less than 50 characters");}
  return correctLen;
  
 
}
 //Method to generate taskID
 public static String taskId(String taskName, int number, String dev_name){
 String taskID ="";
 String firstTwo = taskName.substring(0, 2);
 String lastThree = dev_name.substring(dev_name.length()-3);
 taskID = firstTwo.toUpperCase() +":"+ number +":"+ lastThree.toUpperCase();
 return taskID;
 
 }
 //Method to display results of all other methods
 public static String printTaskDetail( String taskName,String taskId,int number, String dev_name,boolean description){
 StringBuilder display = new StringBuilder();
 String disp ="";
 
 disp = description +"\n*"+ dev_name+"\n*"+ number+"\n"+ taskId;
 return disp;
 } 

 //Method to calculate the estimated time for each task entered
public static int showHours(int duration){
int a = 2;

int b = 2;

int Answer = a + b;
return Answer;

}

}