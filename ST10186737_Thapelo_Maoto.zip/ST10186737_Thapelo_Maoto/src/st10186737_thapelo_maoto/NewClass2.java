/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package st10186737_thapelo_maoto;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Thapelo Maoto
 */
public class NewClass2 {
 
public static String[] task;

public void delete(String x){
    
String[] newTask = new String[task.length-1];

//position on the new array
int t = 0;

//position on the deleted array
int pos = 0;

for(int i = 0; i < task.length;i++){
if(task[i]!=x){
newTask[t]=task[i];
t++;}
else{pos = i;}

int r = 0;

for(int v = 0; v < task.length;v++){
if(i != pos){
newTask[v]=task[i];
r++;}
}

}
newTask = task;
}
public String[] display(String[] task){
    Scanner scn = new Scanner(System.in);
    
    
String[] a ={"Business task","Spaceprogram task","Government task","Military"};
a = task;


int var = Integer.parseInt(JOptionPane.showInputDialog(null,"press one to delete"));
while(var==1){
if(task.length>0){
String tas = JOptionPane.showInputDialog(null,"Enter task you want to delete");
JOptionPane.showMessageDialog(null,tas + " has been deleted");
for(int i = 0; i < task.length;i++){
if(tas == task[i] && tas.equalsIgnoreCase(task[i])){    
delete(tas);
 }
}

for(int i = 0; i < task.length;i++){
 
 var = Integer.parseInt(JOptionPane.showInputDialog(null,"press one to delete"));
 tas = JOptionPane.showInputDialog(null,"Enter task you want to delete");
JOptionPane.showMessageDialog(null,tas + " has been deleted");}


 var = Integer.parseInt(JOptionPane.showInputDialog(null,"press one to delete"));
 JOptionPane.showMessageDialog(null,"You do not have elements to delete");
break;}

}
return this.task;
}
}   

