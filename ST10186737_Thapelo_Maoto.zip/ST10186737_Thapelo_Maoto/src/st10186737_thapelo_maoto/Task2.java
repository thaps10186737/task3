/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package st10186737_thapelo_maoto;

import javax.swing.*;

/**
 *
 * @author Thapelo Maoto
 */
public class Task2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame();

        JOptionPane.showMessageDialog(null, "Welcome To EasyKanban");

        int stop = 0;
        while (stop != 3) {
            int option = Integer.parseInt(JOptionPane.showInputDialog(null, "Select from options\n*"
                    + "Option 1>>Add tasks\n*"
                    + "Option 2>>Show report\n*"
                    + "Option 3>>Quit\n"));

            
             
            
            //Number of task count
            if (option == 1) {
                
                JOptionPane.showMessageDialog(null,"Welcome to User program");
                
                //  
                int count = 0;
                 count = Integer.parseInt(JOptionPane.showInputDialog("Enter number of tasks "));
                for(int r = 0; r < count; r++){
                   
                String task = JOptionPane.showInputDialog(null,"Tasks name" + (r+1));
                JOptionPane.showMessageDialog(frame,"Number of tasks:"+task);
                }
                
             
            

                 
                
                
              // Description of task
             String descript = JOptionPane.showInputDialog("Enter Task Description");
             while(!Task.checkTaskDescription(descript)){
             String description = JOptionPane.showInputDialog("Enter Task Description");
             break;
                
                
                   
                
                }
                

                 

                String taskDuration = JOptionPane.showInputDialog("Task Duration");
                
                
                
     
     
                NewClass set_get = new NewClass();
                NewClass1 set_get1 = new NewClass1();
                JOptionPane.showMessageDialog(frame, Task.taskId("User program", 0,"Thapelo"));
                JOptionPane.showMessageDialog(null, Task.printTaskDetail(taskDuration, descript,0,"", true)+"\n"+
                        set_get1+"\n"+set_get.toString()+ "\n"+"Number of tasks: "+count+"\n"+Task.showHours(option));
                
            //status check    
            int or = Integer.parseInt(JOptionPane.showInputDialog("Check status\n"
                    + "1.To do\n"
                    + "2.Doing\n"
                    + "3.Done"));
            
            if(or == 1){
            JOptionPane.showMessageDialog(null,"To do");}
             else if(or ==2){
            JOptionPane.showMessageDialog(null,"Doing");}
            
            else if(or == 3){
                JOptionPane.showMessageDialog(null,"Done");}
            
            
            
            
            } else if (option == 2) {
            StringBuilder brick = new StringBuilder();
        StringBuilder mansonry = new StringBuilder();
        String[] dev = {"Tim Gordon", "Tom Miller", "Victor Vilakazi", "Mary Ndlovu"};

        String[] taskName = {"Business task", "Military task", "SpaceProgram task", "Government task"};

        int[] durat = new int[]{4, 34, 10, 12};

        String[] taskStatus = {"Do", "Doing", "Done", "Done"};
        for (int i = 0; i < dev.length; i++) {
            brick.append(taskName[i] + "\n" + dev[i] + "\n" + durat[i] + "\n" + taskStatus[i]+"\n"+"\n");
        }

        JOptionPane.showMessageDialog(null, brick.toString());

        for (int i = 0; i < taskName.length; i++) {
            
        }

        for (int i = 0; i < dev.length; i++) {

            JOptionPane.showMessageDialog(null, taskName[i] + ":" + dev[i]);
        }

        // Evaluation of task with longer duration
        int large = durat[0];
        int small = durat[0];
        for (int i = 0; i < durat.length; i++) {
            if (large < durat[i]) {
                large = durat[i];
                JOptionPane.showMessageDialog(null, "Task with greatest duration: " + large + "Hours" + dev[i]);
                
        String searchStatus = JOptionPane.showInputDialog(null,"Enter task status");
        
                        
     ///** Search function
     // search using task name
       String search = JOptionPane.showInputDialog(null,"Enter task"
               + " name to search");
         for(int n = 0; n < taskName.length;n++){
       if(search.equalsIgnoreCase(taskName[n])){  
       
        
        JOptionPane.showMessageDialog(null,"Task Details of:"
                + "\n"
                + " "
                + dev[n]+"\n"+taskName[n]+"\n"+durat[n]+"hours"+"\n"+searchStatus);
         
         //Search using task name
        String scan = JOptionPane.showInputDialog(null,"Enter task name to search");
        for(
            int t = 0; t < taskName.length; t++){
        if(scan.equalsIgnoreCase(taskName[t]))
        { JOptionPane.showMessageDialog(null,"Task Details:"+"\n" +taskName[t] + "\n"+ searchStatus);
        continue;}

        }
       
         }
            }


        } 

        
    }
   //Object for deleting tasks      
   NewClass2 a = new NewClass2();
   a.display(taskName);  
  

        
            }else if(option == 3){
                stop = 3;
                System.exit(0);
                
            }

        }

    }
}


 