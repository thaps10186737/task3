/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package st10186737_thapelo_maoto;

import java.util.Scanner;
// *
// * @author Thapelo Maoto
// */
public class Password extends Username {

    /**
     * @param args the command line arguments
     */
    
    
 public static void main(String[] args){
 Scanner sc = new Scanner(System.in);
 System.out.println("Enter password");
 String user = sc.nextLine();
 
 checkUsername(hasLength(user),hasCharacters(user));
 }
 public static boolean checkUsername(boolean l,boolean c){
 boolean outcome = false;
 if(l && c){
 outcome = true;
     System.out.println("User registered");
 }
 else{ outcome = false;
     System.out.println("Username does not match complexity");
 }
 return outcome;
}


public static boolean hasLength(String user){
    
 boolean result = false;
 
 for(int i = 0; i<user.length();i++){
 if(user.length()==5 && user.length()>=5){
 result = true;
     
 break;
 }
 else{result = false;
     }
 break;
 }
 return result;
}
public static boolean hasCharacters(String user){
boolean output =false;

for(int j=0 ;j < user.length(); j++){
if(user.charAt(j)>=94  || user.charAt(j)==95){
output = true;
       
break;
}
else{output = false;
    
break;
}
}
return output;
}

}
    
    
    

